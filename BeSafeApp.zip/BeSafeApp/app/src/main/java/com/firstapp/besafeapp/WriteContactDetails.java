package com.firstapp.besafeapp;

public class WriteContactDetails {
    public String Contact1, Contact2, Contact3;
    public WriteContactDetails(){};
    public WriteContactDetails(String textContact1, String textContact2, String textContact3) {
        this.Contact1 = textContact1;
        this.Contact2 = textContact2;
        this.Contact3 = textContact3;

    }

}
